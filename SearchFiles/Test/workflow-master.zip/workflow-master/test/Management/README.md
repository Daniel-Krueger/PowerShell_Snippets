# Test Application Development for COSMO Workflow for Business Central 16

## Object Ids for Test App

|Module|Description|Test Codunit Id Range|
|---|---|---|
|WF|Object range for shared objects|5103850..5103899|


## Installation and Preparation

### Preparation
* Clone the GitLap Repository 
* Switch to the TestAppDevelopment Branch ("git switch TestAppDevelopment")

### Install Development Environment
* Install Docker Desktop
* Install NAVContainerHelper [01_InstallNavContainerHelper.ps1]
* Create Development Container [02_CreateDevelopmentContainer.ps1]
* Install Visual Studio Code
* Install vsix Extension in Visual Studio: http://WF-BC16-DEV:8080/ALLanguage.vsix

### Preparation of the development environment in Visual Studio Code
* Use template_launch.json in App and TestApp (copy to .vscode folder and rename file to launch.json)
* Download symbols in "app" folder
* Publish WF app (Strg+F5)
* Download symbols in "test" folder