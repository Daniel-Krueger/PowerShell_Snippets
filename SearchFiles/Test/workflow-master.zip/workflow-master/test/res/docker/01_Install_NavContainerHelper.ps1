Set-ExecutionPolicy Unrestricted
install-module navcontainerhelper -force 
import-module navcontainerhelper -Force 
Write-NavContainerHelperWelcomeText 
Set-ExecutionPolicy RemoteSigned