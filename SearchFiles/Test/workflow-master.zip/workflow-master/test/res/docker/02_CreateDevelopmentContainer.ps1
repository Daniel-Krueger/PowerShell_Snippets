$authUser = 'admin'
$authPass = 'admin'
$secpasswd = ConvertTo-SecureString $authPass -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential ($authUser, $secpasswd)

$licenseFile = "C:\development\fin.flf"
$NavContainerName = "WF-BC16-DEV"
$NavBCSVersion = "mcr.microsoft.com/businesscentral/sandbox:16.2.13509.14256-de-ltsc2019"

New-BCContainer -accept_eula `
    -accept_outdated `
    -containerName $NavContainerName `
    -imageName $NavBCSVersion `
    -licenseFile "$licenseFile" `
    -credential $credential `
    -auth NavUserPassword `
    -assignPremiumPlan `
    -updateHosts `
    -alwaysPull `
    -shortcuts Desktop `
    -includeTestToolkit `
    -includeTestLibrariesOnly `
    -includeAL `
    -restart no `
    -doNotCheckHealth